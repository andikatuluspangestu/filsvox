<footer>
 <!-- Ini adalah footer -->
</footer>
</html>