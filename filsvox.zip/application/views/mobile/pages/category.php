<div class="hidden p-4 bg-gray-800" id="dashboard" role="tabpanel" aria-labelledby="dashboard-tab">
  <h1 class="text-2xl text-white block m-5">
    Coming Soon..
  </h1>
</div>