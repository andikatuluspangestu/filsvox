<footer>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <script src="https://cdn.quilljs.com/1.3.6/quill.js"></script>
  <script src="https://cdn.quilljs.com/1.3.6/quill.min.js"></script>
  <script src="https://buttons.github.io/buttons.js" async defer></script>
  <script src="<?= base_url('assets/dashboard/js/scripts.css') ?>"></script>
</footer>