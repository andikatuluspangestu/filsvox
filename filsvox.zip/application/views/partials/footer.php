<footer class="bg-slate-900 text-white pt-12 pb-8 px-4">
  <div class="pt-4 mt-4 pt-6 text-gray-600 border-t border-gray-800 flex flex-col md:flex-row justify-center items-center">
    <div>© 2022 FILSVOX Entertainment Co.LTD.</div>
    <div>&nbsp;All rights reserved.</div>
  </div>
</footer>