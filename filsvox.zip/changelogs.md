### **Changelogs**
All notable changes to this project will be documented in this file.

> [ v2.2.0 ] Released - 10/11/2022 :
- Added : User Register or Sign Up
- Added : User Management
- Added : Introduction Web API for Developers
- Added : Now the mobile version of filsvox is available, still web-based in BETA stage
- Added : Now you can edit user profile
- Added : More role has been added
- Change : Introduce new favicon
- Change : Improve context menu container UI
- Change : Improve count card UI in Dashboard
- Change : Improve Login and Register UI
- Change : Improve Add Category UI Form
- Change : Full Re-design UI for Login Page
- Change : More categories has been deleted
- Fixed  : Minor Bugs
- Issue  : #1 - Edit user profile avatar and password

> [ v2.0.0 ] Released - 05/11/2022 :
- Added : Now you can search or view list film by category
- Added : Now you can add trailer video, if trailer video is not available, you can add only cover image
- Added : Now you can added detail information ( directors, writers and film actors )
- Added : Introduce chart for film count published by month per year
- Added : Introduce chart for film count published by category per year
- Added : You can add new category from admin dashboard, also you can delete category
- Added : Can see all film by category from admin dashboard, if you click on category button
- Change : Merge to Quill.JS for better text editor
- Change : Improve navbar background color in Dashboard
- Change : Improve action buttons in article list
- Change : Full redesign of the dashboard UI
- Change : Full redesign of the form article UI
- Change : Full redesign of the edit form article UI
- Change : Improve folder structure for better scalability
- Fixed : The search result layout display has been fixed
- Fixed : All minor bugs
- Issue : For trailers only supports direct video links, does not support videos from youtube (due to copyright issues)

> [ v1.0.2 ] Released - 29/10/2022 :
- Initial Build
- Initial Public BETA Release
- Added : Landing Page
- Added : Login Page
- Added : Dashboard Page
- Added : Review Page
- Added : Now you can add post, edit post, delete post, and view post
- Added : Now you can search film by title
- Added : Now you can search film by categories
- Added : Use disqus for comment
- Change : Improve UI/UX Dashboard
- Change : Improve UI/UX Review
- Change : Improve UI/UX Landing Page
- Change : Merge to Tailwind CSS Latest version 3.0.7
- Change : Merge to Alpine JS Latest version 3.0.7
- Change : Merge to Bootstrap Icons Latest version
- Fixed   : Fixing some bugs
- Issue  : Film Description is not showing
- Issue  : If wrong password or username, is not showing error message
- Issue  : Can't show multiple categories
- Issue  : Can't add two or more headline, so for now, developer disable headline feature
- Issue  : Others issues or bugs maybe not listed here
- Issue  : Not Responsive on Mobile Devices for now, maybe in the future

> Write by [Andika Tulus Pangestu](github.com/andikatuluspangestu)